﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Coche
    {
        public String Modelo { get; set; }
        public String placa { get; set; }
        public String dueño { get; set; }
        public Trabajador TrabajadorEncagado { get; set; }
        public String FechaNacimiento { get; set; }
    }
}
